 /* particlesJS.load(@dom-id, @path-json, @callback (optional)); */
 particlesJS.load('particles-js', 'assets/particles.json', function() {
    console.log('callback - particles.js config loaded');
});

$('#button-start').on('click', function() {
    $('#home').fadeOut('slow')
});

$('#button-start').on('click', function() {
    $('#content-main').fadeIn('slow')
});

$('#button-back').on('click', function() {
    $('#content-main').fadeOut('slow')
});

$('#button-back').on('click', function() {
    $('#home').fadeIn('slow')
});

// Tabs
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

// AFFINE

function encrypt_affine() {
    var word, newword, code, newcode, newletter
    var addkey, multkey
    word = document.getElementById("p").value
    word = word.toLowerCase()
    word = word.replace(/\W/g, "")
    addkey = 0

    add = document.getElementById("add")
    mult = document.getElementById("mult")

    for (i = 0; i < add.length; i++) {
        addkey = addkey + (add[i].text) * (add[i].selected)
    }

    multkey = 0

    for (i = 0; i < mult.length; i++) {
        multkey = multkey + (mult[i].text) * (mult[i].selected)
    }

    newword = ""

    for (i = 0; i < word.length; i++) {
        code = word.charCodeAt(i) - 97
        newcode = ((multkey * code + addkey) % 26) + 97
        newletter = String.fromCharCode(newcode)
        newword = newword + newletter
    }

    document.getElementById("c").value = newword + " "
}

function decrypt_affine() {
    var word, newword, code, newcode, newletter
    var addkey, multkey, multinverse

    word = document.getElementById("c").value
    word = word.toLowerCase()
    word = word.replace(/\W/g, "")
    addkey = 0

    add = document.getElementById("add")
    mult = document.getElementById("mult")

    for (i = 0; i < add.length; i++) {
        addkey = addkey + (add[i].text) * (add[i].selected)
    }

    multkey = 0

    for (i = 0; i < mult.length; i++) {
        multkey = multkey + (mult[i].text) * (mult[i].selected)
    }

    multinverse = 1

    for (i = 1; i <= 25; i = i + 2) {
        if ((multkey * i) % 26 == 1) {
            multinverse = i
        }
    }

    newword = ""

    for (i = 0; i < word.length; i++) {
        code = word.charCodeAt(i) - 97
        newcode = ((multinverse * (code + 26 - addkey)) % 26) + 97
        newletter = String.fromCharCode(newcode)
        newword = newword + newletter
    }

    document.getElementById("p").value = newword.toLowerCase()
}

// End of Affine

// Vignere
const app = new function() {
        this.doCrypt = function(isDecrypt) {
        const keyStr = document.getElementById("key").value;
        if (keyStr.length == 0) {
            alert("Key is empty");
            return;
        }

        let keyArray = filterKey(keyStr);
        if (keyArray.length == 0) {
            alert("Key has no letters");
            return;
        }

        if (isDecrypt) {
            for (let i = 0; i < keyArray.length; i++)
                keyArray[i] = (26 - keyArray[i]) % 26;
        }

        let textElem = document.getElementById("text");
        textElem.value = crypt(textElem.value, keyArray);
    };


    /* 
     * Returns the result the Vigenère encryption on the given text with the given key.
     */
    function crypt(input, key) {
        let output = "";
        let j = 0;
        for (const ch of input) {
            const cc = ch.codePointAt(0);
            if (isUppercase(cc)) {
                output += String.fromCodePoint((cc - 65 + key[j % key.length]) % 26 + 65);
                j++;
            } else if (isLowercase(cc)) {
                output += String.fromCodePoint((cc - 97 + key[j % key.length]) % 26 + 97);
                j++;
            } else {
                output += ch;
            }
        }
        return output;
    }


    /* 
     * Returns an array of numbers, each in the range [0, 26), representing the given key.
     * The key is case-insensitive, and non-letters are ignored.
     * Examples:
     * - filterKey("AAA") = [0, 0, 0].
     * - filterKey("abc") = [0, 1, 2].
     * - filterKey("the $123# EHT") = [19, 7, 4, 4, 7, 19].
     */
    function filterKey(key) {
        let result = [];
        for (const ch of key) {
            const cc = ch.codePointAt(0);
            if (isLetter(cc))
                result.push((cc - 65) % 32);
        }
        return result;
    }


    // Tests whether the given character code is a Latin letter.
    function isLetter(c) {
        return isUppercase(c) || isLowercase(c);
    }

    // Tests whether the given character code is an Latin uppercase letter.
    function isUppercase(c) {
        return 65 <= c && c <= 90; // 65 is character code for 'A'. 90 is 'Z'.
    }

    // Tests whether the given character code is a Latin lowercase letter.
    function isLowercase(c) {
        return 97 <= c && c <= 122; // 97 is character code for 'a'. 122 is 'z'.
    }

    // End of Vignere

    // Caesar Cipher
    this.doCryptCaesar = function(isDecrypt) {
        const shiftText = document.getElementById("shift").value;
        if (!/^-?\d+$/.test(shiftText)) {
            alert("Shift is not an integer");
            return;
        }
        let shift = parseInt(shiftText, 10);
        if (shift < 0 || shift >= 26) {
            alert("Shift is out of range");
            return;
        }
        if (isDecrypt)
            shift = (26 - shift) % 26;
        let textElem = document.getElementById("text");
        textElem.value = caesarShift(textElem.value, shift);
    };


    /* 
     * Returns the result of having each alphabetic letter of the given text string shifted forward
     * by the given amount, with wraparound. Case is preserved, and non-letters are unchanged.
     * Examples:
     * - caesarShift("abz",  0) = "abz".
     * - caesarShift("abz",  1) = "bca".
     * - caesarShift("abz", 25) = "zay".
     * - caesarShift("THe 123 !@#$", 13) = "GUr 123 !@#$".
     */
    function caesarShift(text, shift) {
        const UPPER_A = "A".codePointAt(0);
        const LOWER_A = "a".codePointAt(0);
        let result = "";
        for (const ch of text) {
            let cc = ch.codePointAt(0);
            if (UPPER_A <= cc && cc <= "Z".codePointAt(0)) // Uppercase
                cc = (cc - UPPER_A + shift) % 26 + UPPER_A;
            else if (LOWER_A <= cc && cc <= "z".codePointAt(0)) // Lowercase
                cc = (cc - LOWER_A + shift) % 26 + LOWER_A;
            result += String.fromCodePoint(cc);
        }
        return result;
    }
    // End of cipher
};

// Atbash cipher

function encode_atbash() {
    plaintext = document.getElementById("plain").value.toLowerCase();
    key = "ZYXWVUTSRQPONMLKJIHGFEDCBA".toLowerCase();
    ciphertext = "";
    var re = /[a-z]/;
    for (i = 0; i < plaintext.length; i++) {
        if (re.test(plaintext.charAt(i))) ciphertext += key.charAt(plaintext.charCodeAt(i) - 97);
        else ciphertext += plaintext.charAt(i);
    }
    document.getElementById("chiper").value = ciphertext;
}

function decode_atbash() {
    ciphertext = document.getElementById("chiper").value.toLowerCase();
    key = "ZYXWVUTSRQPONMLKJIHGFEDCBA".toLowerCase();
    plaintext = "";
    var re = /[a-z]/;
    for (i = 0; i < ciphertext.length; i++) {
        if (re.test(ciphertext.charAt(i))) plaintext += String.fromCharCode(key.indexOf(ciphertext.charAt(i)) + 97);
        else plaintext += ciphertext.charAt(i);
    }
    document.getElementById("plain").value = plaintext;
}

// End of atbash cipher

// Hill cipher

function encode_hill() {
    plaintext = document.getElementById("plain_hill").value.toLowerCase().replace(/[^a-z]/g, "");
    k = document.getElementById("key_hill").value.toLowerCase().replace(/[^0-9 ]/g, "");
    keys = k.split(" ");
    // do some error checking
    if (plaintext.length < 1) {
        alert("please enter some plaintext (letters and numbers only)");
        return;
    }
    if (plaintext.length % 2 == 1) {
        plaintext = plaintext + "x";
    }
    if (keys.length != 4) {
        alert("key should consist of 4 integers");
        return;
    }
    for (i = 0; i < 4; i++) keys[i] = keys[i] % 26;
    ciphertext = "";
    for (i = 0; i < plaintext.length; i += 2) {
        ciphertext += String.fromCharCode((keys[0] * (plaintext.charCodeAt(i) - 97) + keys[1] * (plaintext.charCodeAt(i + 1) - 97)) % 26 + 97);
        ciphertext += String.fromCharCode((keys[2] * (plaintext.charCodeAt(i) - 97) + keys[3] * (plaintext.charCodeAt(i + 1) - 97)) % 26 + 97);
    }
    document.getElementById("cipher_hill").value = ciphertext;
}

function decode_hill() {
    ciphertext = document.getElementById("cipher_hill").value.toLowerCase().replace(/[^a-z]/g, "");
    k = document.getElementById("key_hill").value.toLowerCase().replace(/[^0-9 ]/g, "");
    keys = k.split(" ");
    // do some error checking 
    if (ciphertext.length < 1) {
        alert("please enter some ciphertext (letters only, numbers should be spelled)");
        return;
    }
    if (ciphertext.length % 2 == 1) {
        alert("ciphertext is not divisible by 2 (wrong algorithm?)");
        return;
    }
    if (keys.length != 4) {
        alert("key should consist of 4 integers");
        return;
    }
    for (i = 0; i < 4; i++) keys[i] = keys[i] % 26;
    // calc inv matrix
    det = keys[0] * keys[3] - keys[1] * keys[2];
    det = ((det % 26) + 26) % 26;
    di = 0;
    for (i = 0; i < 26; i++) {
        if ((det * i) % 26 == 1) di = i;
    }
    if (di == 0) {
        alert("could not invert, try different key");
        return;
    }
    ikeys = new Array(4);
    ikeys[0] = (di * keys[3]) % 26;
    ikeys[1] = (-1 * di * keys[1]) % 26;
    ikeys[2] = (-1 * di * keys[2]) % 26;
    ikeys[3] = di * keys[0];
    for (i = 0; i < 4; i++) {
        if (ikeys[i] < 0) ikeys[i] += 26;
    }
    plaintext = "";
    for (i = 0; i < ciphertext.length; i += 2) {
        plaintext += String.fromCharCode((ikeys[0] * (ciphertext.charCodeAt(i) - 97) + ikeys[1] * (ciphertext.charCodeAt(i + 1) - 97)) % 26 + 97);
        plaintext += String.fromCharCode((ikeys[2] * (ciphertext.charCodeAt(i) - 97) + ikeys[3] * (ciphertext.charCodeAt(i + 1) - 97)) % 26 + 97);
    }
    document.getElementById("plain_hill").value = plaintext;
}

// End of hill cipher

// Playfair cipher

function encode_playfair() {
    plaintext = document.getElementById("plain_playfair").value.toLowerCase().replace(/[^a-z]/g, "").replace(/[j]/g, "i");
    keysquare = document.getElementById("keysquare").value.toLowerCase().replace(/[^a-z]/g, "");
    // do some error checking
    if (plaintext.length < 1) {
        alert("please enter some plaintext (letters and numbers only)");
        return;
    }
    if (keysquare.length != 25) {
        alert("keysquare must be 25 characters in length");
        return;
    }
    while (plaintext.length % 2 != 0) plaintext += "x";
    ciphertext = "";
    for (i = 0; i < plaintext.length; i += 2) {
        a = plaintext.charAt(i);
        b = plaintext.charAt(i + 1);
        if (a == b) b = "x";
        row1 = parseInt(keysquare.indexOf(a) / 5);
        col1 = keysquare.indexOf(a) % 5;
        row2 = parseInt(keysquare.indexOf(b) / 5);
        col2 = keysquare.indexOf(b) % 5;
        if (row1 == row2) {
            if (col1 == 4) c = keysquare.charAt(row1 * 5);
            else c = keysquare.charAt(row1 * 5 + col1 + 1);
            if (col2 == 4) d = keysquare.charAt(row2 * 5);
            else d = keysquare.charAt(row2 * 5 + col2 + 1);
        } else if (col1 == col2) {
            if (row1 == 4) c = keysquare.charAt(col1);
            else c = keysquare.charAt((row1 + 1) * 5 + col1);
            if (row2 == 4) d = keysquare.charAt(col2);
            else d = keysquare.charAt((row2 + 1) * 5 + col2);
        } else {
            c = keysquare.charAt(row1 * 5 + col2);
            d = keysquare.charAt(row2 * 5 + col1);
        }

        ciphertext += c + d;
    }
    document.getElementById("cipher_playfair").value = ciphertext.toUpperCase();
}

function decode_playfair() {
    ciphertext = document.getElementById("cipher_playfair").value.toLowerCase().replace(/[^a-z0-9]/g, "").replace(/[j]/g, "i");;
    keysquare = document.getElementById("keysquare").value.toLowerCase().replace(/[^a-z]/g, "");
    if (ciphertext.length < 1) {
        alert("please enter some ciphertext (letters only)");
        return;
    }
    if (ciphertext.length % 2 != 0) {
        alert("ciphertext length must be even.");
        return;
    }
    if (keysquare.length != 25) {
        alert("keysquare must be 25 characters in length");
        return;
    }

    plaintext = "";
    for (i = 0; i < ciphertext.length; i += 2) {
        a = ciphertext.charAt(i);
        b = ciphertext.charAt(i + 1);
        row1 = parseInt(keysquare.indexOf(a) / 5);
        col1 = keysquare.indexOf(a) % 5;
        row2 = parseInt(keysquare.indexOf(b) / 5);
        col2 = keysquare.indexOf(b) % 5;
        if (row1 == row2) {
            if (col1 == 0) c = keysquare.charAt(row1 * 5 + 4);
            else c = keysquare.charAt(row1 * 5 + col1 - 1);
            if (col2 == 0) d = keysquare.charAt(row2 * 5 + 4);
            else d = keysquare.charAt(row2 * 5 + col2 - 1);
        } else if (col1 == col2) {
            if (row1 == 0) c = keysquare.charAt(20 + col1);
            else c = keysquare.charAt((row1 - 1) * 5 + col1);
            if (row2 == 0) d = keysquare.charAt(20 + col2);
            else d = keysquare.charAt((row2 - 1) * 5 + col2);
        } else {
            c = keysquare.charAt(row1 * 5 + col2);
            d = keysquare.charAt(row2 * 5 + col1);
        }
        plaintext += c + d;
    }
    document.getElementById("plain_playfair").value = plaintext.toUpperCase();
}

function GenRandKey() {
    var keychars = "abcdefghiklmnopqrstuvwxyz";
    var chars = keychars.split("");
    ret = "";
    lim = chars.length
    for (i = 0; i < lim; i++) {
        index = Math.floor(chars.length * Math.random());
        ret += chars[index];
        chars.splice(index, 1);
    }
    document.getElementById("keysquare").value = ret;
}

// End of playfair

// Transposition cipher
// End of transposition
// caesar

